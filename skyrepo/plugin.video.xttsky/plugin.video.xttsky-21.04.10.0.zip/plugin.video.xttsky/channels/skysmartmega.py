# -*- coding: utf-8 -*-
import re, os
import sys
import urllib
# import math
import json
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import time
import xttskytools
import skyxttseries
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
# channels = xbmc.translatePath(os.path.join(home, 'channels'))
# sys.path.append(channels)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon = __settings__.getAddonInfo('icon')
filename = "skysmartmega"
dataurlmega = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMDM7JiMxMDU7JiMxMTY7JiMxMDQ7JiMxMTc7JiM5ODsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzExNTsmIzEwNzsmIzEyMTsmIzEyMDsmIzExNjsmIzExNjsmIzEwMDsmIzk3OyYjMTE2OyYjOTc7JiM0NzsmIzExNTsmIzEwNzsmIzEyMTsmIzEwOTsmIzk5OyYjMTAwOyYjOTc7JiMxMTY7JiM5NzsmIzQ3OyYjMTE2OyYjMTE0OyYjMTAxOyYjMTAxOyYjNDc7JiMxMDk7JiM5NzsmIzExNTsmIzExNjsmIzEwMTsmIzExNDsmIzQ3OyYjMTEyOyYjMTA5OyYjMTAwOyYjOTc7JiMxMTY7JiM5NzsmIzEwOTsmIzEwMTsmIzEwMzsmIzk3OyYjNDc7"
dataurlmega2 = "JiMxMDQ7JiMxMTY7JiMxMTY7JiMxMTI7JiMxMTU7JiM1ODsmIzQ3OyYjNDc7JiMxMTQ7JiM5NzsmIzExOTsmIzQ2OyYjMTAzOyYjMTA1OyYjMTE2OyYjMTA0OyYjMTE3OyYjOTg7JiMxMTc7JiMxMTU7JiMxMDE7JiMxMTQ7JiM5OTsmIzExMTsmIzExMDsmIzExNjsmIzEwMTsmIzExMDsmIzExNjsmIzQ2OyYjOTk7JiMxMTE7JiMxMDk7JiM0NzsmIzExNTsmIzEwNzsmIzEyMTsmIzEyMDsmIzExNjsmIzExNjsmIzEwMDsmIzk3OyYjMTE2OyYjOTc7JiM0NzsmIzExNTsmIzEwNzsmIzEyMTsmIzEwOTsmIzk5OyYjMTAwOyYjOTc7JiMxMTY7JiM5NzsmIzQ3OyYjMTA5OyYjOTc7JiMxMDU7JiMxMTA7JiM0NzsmIzExMjsmIzEwOTsmIzEwMDsmIzk3OyYjMTE2OyYjOTc7JiMxMDk7JiMxMDE7JiMxMDM7JiM5NzsmIzQ3Ow=="
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
# maininfohtmlxmltest = xttskytools.maininfohtmlxml
# exec(base64.b64decode(''))
def mainmega():
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(xttskytools.decodee(dataurlmega), headers=headers)
    r.raise_for_status()
    match=re.compile('<a.*?title="(.*?).xml".*?.xml</a>').findall(str(r.text))
    for ps in range(len(match)):
        thumbnail = images_path + "/xttsmarttv.png"
        pmdataname = "SMART MEGA  " + "[COLOR red]"+str(ps+1)+"[/COLOR]"
        xttplaymac(filename,"[B][COLOR lightblue]"+str(pmdataname)+"[/COLOR][/B]", "mainmegaopen(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",xttskytools.decodee(dataurlmega2)+match[ps]+'.xml',thumbnail,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
        
def mainmegaopen(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    r.raise_for_status()
    matchttp=re.compile('http://([0-9A-Za-z_\-:\.]+)').findall(str(xttskytools.decodee(r.text.replace('JiMxsKy4tRxTt2', "JiMx"))))
    gelenhttp = []
    for httpgelen in matchttp:
        gelenhttp.append(("http://"+httpgelen))
    match=re.compile('00\:1(?:A|a)?\:79\:([0-9A-Fa-f:]+)\s*').findall(str(xttskytools.decodee(r.text.replace('JiMxsKy4tRxTt2', "JiMx"))))
    for ms in range(len(match)):
        pmdataname = "MEGA LİSTE  " + "[COLOR red]"+str(ms+1)+"[/COLOR]"
        mac = '00:1A:79:' + match[ms].replace("\n", "").replace("\s", "").replace(' ','')
        xttplaymac(filename,"[B][COLOR lightblue]"+str(pmdataname)+"[/COLOR][/B]", "panelmac(url,mac)",str(gelenhttp[0]),images_path + "/xttsmarttv.png","","",str(mac),"","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
def panelmac(url,mac):
    mac = str(mac)
    panelurl = str(url)
    timezone = 'America/Chicago';
    thumbnaillive = images_path + "/xttsmarttv.png"
    thumbnailvod = images_path + "/xttsine.png"
    thumbnailserie = images_path + "/xttmcserie.png"
    xttplaymac(filename,str("LIVE"), "xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnaillive,"","",str(mac),str(timezone),"","itv&action")
    xttplaymac(filename,str("VOD"), "xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailvod,"","",str(mac),str(timezone),"","vod&action")
    xttplaymac(filename,str("SERİES"), "skyxttseries.xttskyseries(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailserie,"","",str(mac),str(timezone),"","series&action")
    xttplaymac(filename,str("LİVE LİSTE"), "getAllChannels(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",str(panelurl),thumbnailvod,"","",str(mac),str(timezone),"","itv&action")
    xbmc.executebuiltin("Container.SetViewMode(500)")
########################  XTTSKY  ###########################
def xttsky(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    try:
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        if not playinfo !="itv&action":
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_genres',
                'JsHttpRequest' : '1-xml',
                'mac' : mac})
            playinfo = "itv&action"
        else:
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'vod', 
                'action' : 'get_categories',
                'JsHttpRequest' : '1-xml',
                'mac' : mac})
            playinfo = "vod&action"
        results = info['js']
        for listeler in results:
            if  not listeler['id'] != '*':
                pass
            else:
                if 'xxx' in listeler['title'] or 'xxX' in listeler['title'] or 'xXX' in listeler['title'] or 'XXX' in listeler['title'] or 'XXx' in listeler['title'] or 'Xxx' in listeler['title'] or 'Adul' in listeler['title'] or 'ADul' in listeler['title'] or 'ADUl' in listeler['title'] or 'ADUL' in listeler['title'] or 'aDUL' in listeler['title'] or 'adUL' in listeler['title'] or 'aduL' in listeler['title'] or 'adul' in listeler['title']:
                    if __settings__.getSetting("yetiskinackapat") == "true":
                        idler = listeler['id']
                        title= listeler['title']
                        thumbnaillive = images_path + "/xttmctv.png"
                        xttplaymac(filename,title, "xttsky18topla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",url,thumbnaillive,"",str(idler),str(mac),str(timezone),"",str(playinfo))
                    else:
                        pass
                else:
                    idler = listeler['id']
                    title= listeler['title']
                    thumbnaillive = images_path + "/xttmctv.png"
                    xttplaymac(filename,title, "xttskytoplaepg(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",url,thumbnaillive,"",str(idler),str(mac),str(timezone),"",str(playinfo))
        xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
        xbmc.executebuiltin("Container.SetViewMode(500)")
    except:
        return playList.clear(exit())
def xttskytoplaepg(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    if playinfo !="itv&action":
        return xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
    else:
        try:
            epgget = xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
        except:
            pass
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        for page in range(1, 500):
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_ordered_list',
                'genre' : fix,
                'p' : page,
                'fav' : '0',
                'JsHttpRequest' : '1-xml'})
            results = info['js']['data']
            if not results !=[]:
                break
            else:
                for listeler in results:
                    name = listeler["name"]
                    ch_id = listeler['id']
                    cmd = "http://localhost/ch/"+ch_id+"_"
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    epghits = []
                    try:
                        epgtime = epgget[ch_id]
                        for epggelen in epgtime:
                            try:
                                if not epggelen['t_time'] !="":
                                    pass
                                else:
                                    tarih = "[B][COLOR yellow]"+epggelen['on_date']+"[/COLOR][/B]"
                                    epghits.append((tarih))
                            except: pass
                            try:
                                if not epggelen['name'] !="":
                                    pass
                                else:
                                    program = "[B][COLOR blue]Program : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['name']+"[/COLOR][/B]"
                                    epghits.append((program))
                            except: pass
                            try:
                                if not epggelen['t_time'] !="":
                                    pass
                                else:
                                    zaman = "[B][COLOR blue]Başlangıç : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time']+"[/COLOR][/B] - [B][COLOR blue]Bitiş : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time_to']+"[/COLOR][/B]"
                                    epghits.append((zaman))
                            except: pass
                            try:
                                if not epggelen['descr'] !="" or not epggelen['descr'] !="\n" or not epggelen['descr'] !=" ":
                                    pass
                                else:
                                    konu = "[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['descr']+"[/COLOR][/B]"
                                    epghits.append((konu))
                            except: pass
                            # print (epggelen['on_date']+" - "+epggelen['t_time']+" - "+epggelen['t_time_to']+"\n"+epggelen['name']+"\n"+epggelen['descr']+"\n")
                    except: pass
                    if not epghits != []:
                        labels = "[B][COLOR blue]"+name+"[/COLOR][/B]"
                    else:
                        labels = replace_fix(str(epghits))
                    xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmcplugin.setContent(int(sys.argv[1]), 'movies')
def xttskytopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    if playinfo !="itv&action":
        return xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
    else:
        tokenkey = handshake(panelurl,mac,timezone)
        timezone = getProfile(panelurl,mac,tokenkey,timezone)
        for page in range(1, 500):
            info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                'type' : 'itv', 
                'action' : 'get_ordered_list',
                'genre' : fix,
                'p' : page,
                'fav' : '0',
                'JsHttpRequest' : '1-xml'})
            results = info['js']['data']
            if not results !=[]:
                break
            else:
                for listeler in results:
                    name = listeler["name"]
                    ch_id = listeler['id']
                    cmd = "http://localhost/ch/"+ch_id+"_"
                    logo = listeler['logo']
                    if not logo !="":
                        logo = images_path + "/xttsmart.png"
                    else:
                        logo = logo
                    labels = name
                    xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
                xbmc.executebuiltin("Container.SetViewMode(500)")
    xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
    
def xttskyvodtopla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    for page in range(1, 500):
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod', 
            'action' : 'get_ordered_list',
            'category' : fix,
            'p' : page,
            'fav' : '0',
            'JsHttpRequest' : '1-xml'})
        results = info['js']['data']
        if not results !=[]:
            break
        else:
            for listeler in results:
                name = listeler["name"]
                cmd = listeler['cmd']
                logo = listeler['screenshot_uri']
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                labelsgroup = []
                try:
                    if not listeler['genres_str'] !="N/A":
                        pass
                    else:
                        tur = '[B][COLOR blue]Tür : [/COLOR][/B][B][COLOR darkgray]'+listeler['genres_str']+'[/COLOR][/B]'
                        labelsgroup.append((tur))
                except: pass
                try:
                    if not listeler['director'] !="N/A":
                        pass
                    else:
                        director = '[B][COLOR blue]Yönetmen : [/COLOR][/B][B][COLOR darkgray]'+listeler['director']+'[/COLOR][/B]'
                        labelsgroup.append((director))
                except: pass
                try:
                    if not listeler['actors'] !="N/A":
                        pass
                    else:
                        actors = '[B][COLOR blue]Oyuncular : [/COLOR][/B][B][COLOR darkgray]'+listeler['actors']+'[/COLOR][/B]'
                        labelsgroup.append((actors))
                except: pass
                try:
                    if not listeler['year'] !="N/A":
                        pass
                    else:
                        year = '[B][COLOR blue]Yapım Yılı : [/COLOR][/B][B][COLOR darkgray]'+listeler['year']+'[/COLOR][/B]'
                        labelsgroup.append((year))
                except: pass
                puantime = []
                try:
                    try:
                        if not listeler['time'] !="N/A" or not listeler['time'] !=0:
                            pass
                        else:
                            time = '[B][COLOR blue]Süre : [/COLOR][/B][B][COLOR darkgray]'+str(listeler['time'])+'[/COLOR][/B]'
                            # print (str(time))
                            puantime.append((str(time)))
                    except: pass
                    try:
                        if not listeler['rating_imdb'] !="N/A":
                            pass
                        else:
                            rating = '[B][COLOR blue]IMBD : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_imdb']+'[/COLOR][/B]'
                            puantime.append((rating))
                    except: pass
                except: pass
                if not puantime !=[]:
                    pass
                else:
                    timeimbd = str(puantime).replace('", "', "  ").replace('\', "', "  ").replace('", \'', "  ").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace("', '", "    ").replace('", "', "    ").replace('\', "', "    ").replace('", \'', "    ")
                    # print (timeimbd)
                    labelsgroup.append((timeimbd))
                # try:
                    # MPAA = '[B][COLOR blue]MPAA : [/COLOR][/B][B][COLOR darkgray]'+listeler['rating_kinopoisk']+'[/COLOR][/B]'
                    # labelsgroup.append((MPAA))
                # except: pass
                
                # try:
                    # if not listeler['age'] !="N/A":
                        # pass
                    # else:
                        # age = '[B][COLOR blue]Yaş Sınırı : [/COLOR][/B][B][COLOR darkgray]'+listeler['age']+'[/COLOR][/B]'
                        # labelsgroup.append((age))
                # except: pass
                try:
                    if not listeler['description'] !="N/A":
                        pass
                    else:
                        plot = '[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR yellow]'+listeler['description']+'[/COLOR][/B]'
                        labelsgroup.append((plot))
                except: pass
                if not labelsgroup !=[]:
                    labels = "[B][COLOR blue]"+name+"[/COLOR][/B]"
                else:
                    labels = replace_fix(str(labelsgroup))
                xttplaymeta(filename,str(name), "testplayermeta(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    xbmc.executebuiltin("Container.SetViewMode(54)")
def xttsky18topla(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    fix = str(fix)
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    datalog = __settings__.getSetting("yetiskinpassbelirle")
    if datalog == "":
        __settings__.openSettings()
        if datalog == "":
            return playList.clear(exit())
    else:
        if __settings__.getSetting("yetiskinpassbelirle") == __settings__.getSetting("yetiskinpassonayla"):
            for page in range(1, 500):
                if not playinfo !="itv&action":
                    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                        'type' : 'itv', 
                        'action' : 'get_ordered_list',
                        'genre' : fix,
                        'p' : page,
                        'fav' : '0',
                        'JsHttpRequest' : '1-xml'})
                else:
                    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                        'type' : 'vod', 
                        'action' : 'get_ordered_list',
                        'category' : fix,
                        'p' : page,
                        'fav' : '0',
                        'JsHttpRequest' : '1-xml'})
                results = info['js']['data']
                if not results !=[]:
                    break
                else:
                    for listeler in results:
                        # id = i["id"]
                        # number = i["number"]
                        name = listeler["name"]
                        if not playinfo !="itv&action":
                            ch_id = listeler['id']
                            cmd = "http://localhost/ch/"+ch_id+"_"
                            logo = listeler['logo']
                        else:
                            cmd = listeler['cmd']
                            logo = listeler['screenshot_uri']
                        if not logo !="":
                            logo = images_path + "/xttsmart.png"
                        else:
                            logo = logo
                        xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
                    xbmc.executebuiltin("Container.SetViewMode(500)")
            xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
            xbmc.executebuiltin("Container.SetViewMode(500)")
        else:
            dialog = xbmcgui.Dialog()
            nr = dialog.input("Denetim Şifrenizi Giriniz", type=xbmcgui.INPUT_NUMERIC)
            if __settings__.getSetting("yetiskinpassbelirle") == nr:
                for page in range(1, 500):
                    if not playinfo !="itv&action":
                        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                            'type' : 'itv', 
                            'action' : 'get_ordered_list',
                            'genre' : fix,
                            'p' : page,
                            'fav' : '0',
                            'JsHttpRequest' : '1-xml'})
                    else:
                        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
                            'type' : 'vod', 
                            'action' : 'get_ordered_list',
                            'category' : fix,
                            'p' : page,
                            'fav' : '0',
                            'JsHttpRequest' : '1-xml'})
                    results = info['js']['data']
                    if not results !=[]:
                        break
                    else:
                        for listeler in results:
                            name = listeler["name"]
                            if not playinfo !="itv&action":
                                ch_id = listeler['id']
                                cmd = "http://localhost/ch/"+ch_id+"_"
                                logo = listeler['logo']
                            else:
                                cmd = listeler['cmd']
                                logo = listeler['screenshot_uri']
                            if not logo !="":
                                logo = images_path + "/xttsmart.png"
                            else:
                                logo = logo
                            xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
                        xbmc.executebuiltin("Container.SetViewMode(500)")
                xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
                xbmc.executebuiltin("Container.SetViewMode(500)")
def getAllChannels(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'itv', 
        'action' : 'get_all_channels',
        'JsHttpRequest' : '1-xml'})
    try:
        results = info['js']['data'];
        try:
            epgget = xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)
        except: pass
        for i in results:
            name = i["name"]
            ch_id = i["id"]
            cmd = "http://localhost/ch/"+ch_id+"_"
            logo 	= i["logo"]
            if not logo !="":
                logo = images_path + "/xttsmart.png"
            else:
                logo = logo
            _s1 = cmd.split(' ');	
            cmd = _s1[0];
            if len(_s1)>1:
                cmd = _s1[1];
            epghits = []
            try:
                epgtime = epgget[ch_id]
                for epggelen in epgtime:
                    try:
                        if not epggelen['t_time'] !="":
                            pass
                        else:
                            tarih = "[B][COLOR yellow]"+epggelen['on_date']+"[/COLOR][/B]"
                            epghits.append((tarih))
                    except: pass
                    
                    try:
                        if not epggelen['name'] !="":
                            pass
                        else:
                            program = "[B][COLOR blue]Program : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['name']+"[/COLOR][/B]"
                            epghits.append((program))
                    except: pass
                    
                    try:
                        if not epggelen['t_time'] !="":
                            pass
                        else:
                            zaman = "[B][COLOR blue]Başlangıç : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time']+"[/COLOR][/B] - [B][COLOR blue]Bitiş : [/COLOR][/B][B][COLOR darkgray]"+epggelen['t_time_to']+"[/COLOR][/B]"
                            epghits.append((zaman))
                    except: pass
                    
                    try:
                        if not epggelen['descr'] !="" or not epggelen['descr'] !="\n" or not epggelen['descr'] !=" ":
                            pass
                        else:
                            konu = "[B][COLOR blue]Konu : [/COLOR][/B][B][COLOR whitesmoke]"+epggelen['descr']+"[/COLOR][/B]"
                            epghits.append((konu))
                    except: pass
                    # print (epggelen['on_date']+" - "+epggelen['t_time']+" - "+epggelen['t_time_to']+"\n"+epggelen['name']+"\n"+epggelen['descr']+"\n")
            except: pass
            if not epghits != []:
                labels = "Bilgi Eklenmemiş"
            else:
                labels = replace_fix(str(epghits))
            xttplaymeta(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo),labels)
    except:
        try:
            for i in results:
                name = i["name"]
                ch_id = i["id"]
                cmd = "http://localhost/ch/"+ch_id+"_"
                logo 	= i["logo"]
                if not logo !="":
                    logo = images_path + "/xttsmart.png"
                else:
                    logo = logo
                _s1 = cmd.split(' ');	
                cmd = _s1[0];
                if len(_s1)>1:
                    cmd = _s1[1];
                xttplaymac(filename,str(name), "testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo)",panelurl,str(logo),"",str(cmd).replace('ffmpeg ', ''),str(mac),str(timezone),"",str(playinfo))
        except:
            return playList.clear(exit())
    xttplaymac(filename,"ANA MENU", "mainmega()","",images_path + "/anasayfa.png","","","","","","")
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    # xbmc.executebuiltin("Container.SetViewMode(500)")
    # xbmc.executebuiltin("Container.SetViewMode(54)")
def testplayer(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'watchdog',
        'action' : 'get_events',
        'init' : '0',
        'cur_play_type' : '1',
        'event_active_id' : '0'})
        
    if not playinfo !="itv&action":
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'itv',
            'action' : 'create_link',
            'cmd' : str(fix)});
    else:
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod',
            'action' : 'create_link',
            'cmd' : str(fix)});
    cmd = info['js']['cmd'];
    url = str(cmd).replace('ffmpeg ', '')
    # print (cmd)
    # s = cmd.split(' ');
    # url = s[0];
    # if len(s)>1:
        # url = s[1];
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', infoLabels={"plot": str(metainfo)})
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
    
    # progress = xbmcgui.DialogProgress()
    # progress.create('Kontrol Ediliyor...', 'Lütfen Bekleyin...')
    # progress.update(15)
    # xbmc.sleep(50)
    # if thumbnail != "":
        # thumbfolder = os.path.join(images_path, "xttsmart.png")
    # listitem = xbmcgui.ListItem()
    # listitem.setArt({'thumb': thumbnail or thumbfolder})
    # listitem.setInfo('Video', {'title': name,
     # 'Seekable': 'false',
     # 'SeekEnabled': 'false'})
    # listitem.setInfo('Video', infoLabels={"plot": str(metainfo)})
    # listitem.setLabel(name)
    # listitem.setPath(url)
    # listitem.setProperty('IsPlayable', 'true')
    # listitem.setProperty('IsNotSeekable', 'true')
    # listitem.setProperty('Seekable', 'false')
    # listitem.setProperty('SeekEnabled', 'false')
    # progress.update(30)
    # xbmcPlayer.play(url,listitem)
    # progress.update(45)
    # abortReason = ''
    # step = 1
    # t = time.time()
    # player = xbmc.Player()
    # monitor = xbmc.Monitor()
    # while not abortReason:
        # if monitor.abortRequested():
            # abortReason = 'aborted'
        # elif progress.iscanceled():
            # abortReason = 'cancelled'
        # elif time.time() - t > 60:
            # abortReason = 'timeout'
        # elif step == 1:
            # if player.isPlaying():
                # progress.update(60)
                # step = 2
        # elif step == 2:
            # if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                # progress.update(75)
                # step = 3
        # elif step == 3:
            # if True or player.isPlaying() and player.getTime() > 0.1:
                # progress.update(100)
                # break
        # if not abortReason:
            # xbmc.sleep(250)
    # xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
    
def testplayermeta(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'watchdog',
        'action' : 'get_events',
        'init' : '0',
        'cur_play_type' : '1',
        'event_active_id' : '0'})
    if not playinfo !="itv&action":
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'itv',
            'action' : 'create_link',
            'cmd' : str(fix)});
    else:
        info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
            'type' : 'vod',
            'action' : 'create_link',
            'cmd' : str(fix)});
    cmd = info['js']['cmd'];
    url = str(cmd).replace('ffmpeg ', '')
    # s = cmd.split(' ');
    # url = s[0];
    # if len(s)>1:
        # url = s[1];
    if thumbnail != "":
        thumbfolder = os.path.join(images_path, "xttsmart.png")
    listitem = xbmcgui.ListItem(name)
    listitem.setArt({'thumb': thumbnail or thumbfolder})
    listitem.setInfo('video', infoLabels={"plot": str(metainfo)})
    playList.add(url,listitem=listitem)
    xbmcPlayer.play(playList)
    return playList.clear(exit())
    
    # progress = xbmcgui.DialogProgress()
    # progress.create('Kontrol Ediliyor...', 'Lütfen Bekleyin...')
    # progress.update(15)
    # xbmc.sleep(50)
    # if thumbnail != "":
        # thumbfolder = os.path.join(images_path, "xttsmart.png")
    # listitem = xbmcgui.ListItem()
    # listitem.setArt({'thumb': thumbnail or thumbfolder})
    # listitem.setInfo('Video', {'title': name,
     # 'Seekable': 'false',
     # 'SeekEnabled': 'false'})
    # listitem.setInfo('Video', infoLabels={"plot": str(metainfo)})
    # listitem.setLabel(name)
    # listitem.setPath(url)
    # listitem.setProperty('IsPlayable', 'true')
    # listitem.setProperty('IsNotSeekable', 'true')
    # listitem.setProperty('Seekable', 'false')
    # listitem.setProperty('SeekEnabled', 'false')
    # progress.update(30)
    # xbmcPlayer.play(url,listitem)
    # progress.update(45)
    # abortReason = ''
    # step = 1
    # t = time.time()
    # player = xbmc.Player()
    # monitor = xbmc.Monitor()
    # while not abortReason:
        # if monitor.abortRequested():
            # abortReason = 'aborted'
        # elif progress.iscanceled():
            # abortReason = 'cancelled'
        # elif time.time() - t > 60:
            # abortReason = 'timeout'
        # elif step == 1:
            # if player.isPlaying():
                # progress.update(60)
                # step = 2
        # elif step == 2:
            # if xbmc.getInfoLabel('VideoPlayer.VideoResolution'):
                # progress.update(75)
                # step = 3
        # elif step == 3:
            # if True or player.isPlaying() and player.getTime() > 0.1:
                # progress.update(100)
                # break
        # if not abortReason:
            # xbmc.sleep(250)
    # xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=listitem,isFolder=False)
    
def xttskygetEPG(name,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):	
    mac = str(mac)
    panelurl = str(url)
    tokenkey = handshake(panelurl,mac,timezone)
    timezone = getProfile(panelurl,mac,tokenkey,timezone)
    infoepg = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'itv', 
        'action' : 'get_epg_info',
        'period' : '6',
        'JsHttpRequest' : '1-xml'})
    resultsepg = infoepg['js']['data'];
    return resultsepg
def handshake(panelurl,mac,timezone):
    tokenkey = ""
    info = Datasearch(panelurl,mac,tokenkey,timezone,values = {
        'type' : 'stb', 
        'action' : 'handshake',
        'JsHttpRequest' : '1-xml'})
    tokenkey = info['js']['token']
    return tokenkey
def getProfile(panelurl,mac,tokenkey,timezone):
    values = {
        'type' : 'stb', 
        'action' : 'get_profile',
        'hd' : '1',
        'ver' : 'ImageDescription:%200.2.18-r11-pub-254;%20ImageDate:%20Wed%20Mar%2018%2018:09:40%20EET%202015;%20PORTAL%20version:%204.9.14;%20API%20Version:%20JS%20API%20version:%20331;%20STB%20API%20version:%20141;%20Player%20Engine%20version:%200x572',
        'num_banks' : '1',
        'stb_type' : 'MAG254',
        'image_version' : '218',
        'auth_second_step' : '0',
        'hw_version' : '2.6-IB-00',
        'not_valid_token' : '0',
        'JsHttpRequest' : '1-xml'}
    info = Datasearch(panelurl,mac,tokenkey,timezone,values);
    passfalse = info['js']['password']
    if not passfalse !="":
        values = {
            'type' : 'stb', 
            'action' : 'get_profile'}
        info = Datasearch(panelurl,mac,tokenkey,timezone,values);
        timezone = info['js']['default_timezone']
        return timezone
    else:
        timezone = info['js']['default_timezone']
        return timezone
def Datasearch(panelurl,mac,tokenkey,timezone,values):
    if not tokenkey !="":
        tokenkey = ""
    else:
        tokenkey = tokenkey
    if not timezone !="":
        timezone = 'America/Chicago';
    else:
        timezone = timezone
    user_agent 	= 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 4 rev: 1812 Mobile Safari/533.3';
    try:
        if not tokenkey !="":
            headers = {
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac+ '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet'};
        else:
            headers = { 
                'User-Agent' : user_agent, 
                'Cookie' : 'mac=' + mac + '; stb_lang=en; timezone=' + timezone,
                'Referer' : panelurl,
                'Accept' : '*/*',
                'Connection' : 'Keep-Alive',
                'X-User-Agent' : 'Model: MAG254; Link: Ethernet',
                'Authorization' : 'Bearer ' + tokenkey };

        load = "/server/load.php"
        data = urllib.parse.urlencode(values)
        rs = requests.get(panelurl + load + '?' + data, headers=headers)
        return rs.json()
    except:
        return playList.clear(exit())
######################################
def xttplaymac(filename,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo):#addDirxbmctrtools
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&filename="+urllib.parse.quote_plus(filename)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"Title": name})
    # liz.setProperty('fanart_image', thumbnail or thumbfolder)
    liz.setProperty('fanart_image', Fanart) or ("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def xttplaymeta(filename,name,method,url,thumbnail,thumbfolder,fix,mac,timezone,tokenkey,playinfo,metainfo):
    if thumbfolder != "":
        thumbfolder = os.path.join(images_path, thumbfolder+".png")
    liz=xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumbnail or thumbfolder})
    liz.setInfo(type="Video", infoLabels={"plot": str(metainfo)})
    liz.setProperty('fanart_image', thumbnail or thumbfolder) or ("IsPlayable", "true")
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(url)+"&method="+str(method)+"&name="+urllib.parse.quote_plus(name)+"&thumbnail="+urllib.parse.quote_plus(thumbnail)+"&thumbfolder="+urllib.parse.quote_plus(thumbfolder)+"&filename="+urllib.parse.quote_plus(filename)+"&fix="+urllib.parse.quote_plus(fix)+"&mac="+urllib.parse.quote_plus(mac)+"&timezone="+urllib.parse.quote_plus(timezone)+"&tokenkey="+urllib.parse.quote_plus(tokenkey)+"&playinfo="+urllib.parse.quote_plus(playinfo)+"&metainfo="+urllib.parse.quote_plus(str(metainfo))
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
def replace_fix(x):
    x=x.replace("\\n", "").replace("\n", "").replace("', '", "\n").replace('", "', "\n").replace('\', "', "\n").replace('", \'', "\n").replace("['", "").replace('["', "").replace("']", "").replace('"]', "").replace('Monday', "Pazartesi").replace('Tuesday', "Salı").replace('Wednesday', "Çarşamba").replace('Thursday', "Perşembe").replace('Friday', "Cuma").replace('Saturday', "Cumartesi").replace('Sunday', "Pazar")
    return x