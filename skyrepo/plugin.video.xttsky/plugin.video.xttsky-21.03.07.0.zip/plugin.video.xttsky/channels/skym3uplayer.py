# -*- coding: utf-8 -*-
import re, os
import sys
import xbmc
import xbmcgui
import xbmcaddon
import requests
import xttskytools
addon_id = 'plugin.video.xttsky'
Addon = xbmcaddon.Addon(addon_id)
__settings__ = xbmcaddon.Addon(id=addon_id)
home = __settings__.getAddonInfo('path')
library = xbmc.translatePath(os.path.join(home, 'resources', 'lib'))
sys.path.append(library)
images_path = xbmc.translatePath(os.path.join(home, 'resources','images'))
sys.path.append(images_path)
Fanart = images_path+'/Fanartbackground.jpg'
addon_icon = __settings__.getAddonInfo('icon')
filename = "skym3uplayer"
xbmcPlayer = xbmc.Player()
xbmcPlayer.stop()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
playList.clear()
def m3umain():
    if __settings__.getSetting("m3u1onoff") == "true":
        m3u1 = __settings__.getSetting("m3u1")
    else:
        m3u1 = ""
    if __settings__.getSetting("m3u2onoff") == "true":
        m3u2 = __settings__.getSetting("m3u2")
    else:
        m3u2 = ""
    if __settings__.getSetting("m3u3onoff") == "true":
        m3u3 = __settings__.getSetting("m3u3")
    else:
        m3u3 = ""
    settingsm3u = []
    datam3u = [
    {"m3ulog": m3u1},
    {"m3ulog": m3u2},
    {"m3ulog": m3u3},
    ]
    for m3usayisi in range(len(datam3u)):
        m3u = datam3u[m3usayisi]['m3ulog']
        print (m3u)
        if not datam3u[m3usayisi]['m3ulog'] != "":
            pass
        else:
            settingsm3u.append((datam3u[m3usayisi]))
    if settingsm3u == []:
        pass
    else:
        for m3uok in range(len(settingsm3u)):
            group_title = 'SMART M3U LİSTE  ' + "[B][COLOR red]"+str(m3uok+1)+"[/COLOR]"
            xttskytools.xttplaymac(filename,"[B][COLOR lightblue]"+str(group_title)+"[/COLOR][/B]", "m3ukategori(url)",str(settingsm3u[m3uok]['m3ulog']),"","xttsmarttv","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def m3ukategori(url):
    bolum=['[COLOR lightblue][B]KANAL LISTESI[/B][/COLOR]','[COLOR darkgray][B]KATEGORI[/B][/COLOR]']
    maintv=['m3ulisteleme','m3ugrup']
    ret = xbmcgui.Dialog().select('[COLOR white][B]IZLEME SECENEKLERI...[/B][/COLOR]', bolum)
    js= maintv[ret]
    if 'm3ulisteleme' in js:
        return m3ulisteleme(str(url))
    else:
        return m3ugrup(str(url))
    return playList.clear(exit())
def m3ugrup(url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    sonuclarm3u = []
    match=re.compile('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="(.*?)".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)').findall(str(r.text))
    for gelenler in match:
        sonuclarm3u.append((gelenler[2]))
    list2 = []
    for i in sonuclarm3u:
      if i not in list2:
        list2.append(i)
    for grouptitle in list2:
        logo = images_path + "/xttsmart.png"
        xttskytools.xttplaymac(filename,str(grouptitle),"m3ugruplist(name,url)",str(url),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def m3ugruplist(name,url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    match=re.compile('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="'+str(name)+'".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)').findall(str(r.text))
    for match1 in match:
        if not match1[1] !="":
            logo = images_path + "/xttsmart.png"
        else:
            logo = str(match1[1])
        xttskytools.xttplaymac(filename,str(match1[0]),"xttskytools.skyxttplayer(name,url,thumbnail)","http://"+str(match1[2]),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")
def m3ulisteleme(url):
    headers = {"user-agent" :"Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"}
    r = requests.get(url, headers=headers)
    for match in re.finditer('#EXTINF.*?name="(.*?)".*?logo="(.*?)".*?title="(.*?)".*?\s*\nhttp:/+/+([0-9A-Za-z_\-:\.\?\/\&\=\+]+)', str(r.text)):
        if not match[2] !="":
            logo = images_path + "/xttsmart.png"
        else:
            logo = str(match[2])
        xttskytools.xttplaymac(filename,str(match[1]),"xttskytools.skyxttplayer(name,url,thumbnail)","http://"+str(match[4]),logo,"","","","","","")
    xbmc.executebuiltin("Container.SetViewMode(500)")